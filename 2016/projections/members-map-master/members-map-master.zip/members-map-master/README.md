# members-map
A GIS map of what ward Chi Hack Night attendees said they live in. Collected on Feb 2, 2016.

During the announcements of a Chi Hack Night meetup in 2016, each person said their name and which ward they live in. We made a tally of this and then Steven Vance quickly made a map by adding a column to the city's wards shapefile. 

Event: http://chihacknight.org/events/2016/02/02/lobbying-chicago-city-council.html

Agenda and meeting notes with source data: https://docs.google.com/document/d/1ZRAJYZNRy-sweVvok9KuIbqlaq9T4xCwmNPV0IcBDHI/edit#heading=h.osuljtwhb7kn
